create view pg_statio_user_tables
            (relid, schemaname, relname, heap_blks_read, heap_blks_hit, idx_blks_read, idx_blks_hit, toast_blks_read,
             toast_blks_hit, tidx_blks_read, tidx_blks_hit)
as
SELECT relid,
       schemaname,
       relname,
       heap_blks_read,
       heap_blks_hit,
       idx_blks_read,
       idx_blks_hit,
       toast_blks_read,
       toast_blks_hit,
       tidx_blks_read,
       tidx_blks_hit
FROM pg_statio_all_tables
WHERE (schemaname <> ALL (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
  AND schemaname !~ '^pg_toast'::text;

alter table pg_statio_user_tables
    owner to "postgres-user";

grant select on pg_statio_user_tables to public;

